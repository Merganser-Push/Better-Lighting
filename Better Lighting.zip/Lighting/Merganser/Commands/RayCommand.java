package Better.Lighting.Merganser.Commands;

import java.util.Collection;
import java.util.Iterator;

import net.minecraft.server.v1_8_R3.EnumParticle;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;
import net.minecraft.server.v1_8_R3.PacketPlayOutWorldParticles;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.bukkit.command.CommandExecutor;
import Better.Lighting.Merganser.Main;

public class RayCommand implements CommandExecutor {
    @SuppressWarnings("deprecation")
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
        if (command.getName().equalsIgnoreCase("shock")) {
            if(args.length > 0) {
                if (args[0]!= null){
                    Player target = Bukkit.getServer().getPlayer(args[0]);
                    if (target == null) { sender.sendMessage(ChatColor.RED+"玩家 "+args[0] + " 不在线！");
                        return true; }
                    target.getWorld().strikeLightning(Bukkit.getPlayer(args[0]).getLocation());
                    target.setVelocity(new Vector(0, 10, 0));
                    createPlayerHelix(Bukkit.getPlayer(args[0]),EnumParticle.SMOKE_LARGE,10,2);
                    createPlayerHelix(Bukkit.getPlayer(args[0]),EnumParticle.ENCHANTMENT_TABLE,5,1);
                    sender.sendMessage(ChatColor.RED + "已击中 "+ChatColor.GOLD+Bukkit.getPlayer(args[0]).getName());
                }
            }else{
                sender.sendMessage(ChatColor.RED+"请输入正确的值！ "+ChatColor.YELLOW+"使用 "+ChatColor.GRAY+"/shock [要使用雷击攻击他人的名称]");
            }
            return true;
        }
        if (command.getName().equalsIgnoreCase("shocka")) {
            Collection<? extends Player> p = Bukkit.getServer().getOnlinePlayers();
            Iterator<? extends Player> it = p.iterator();
            while (it.hasNext()) {
                Player pt = (Player) it.next();
                pt.getWorld().strikeLightning(pt.getLocation());
                pt.setVelocity(new Vector(0, 10, 0));
            }
        }
        return true;
    }
    public void setActionBar(final String s, final Player p) {
        new BukkitRunnable() {

            @Override
            public void run() {

                PacketPlayOutChat packet = new PacketPlayOutChat(ChatSerializer.a("{\"text\":\"" + s + "\"}"), (byte) 2);
                ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
            }
        }.runTaskAsynchronously(Main.base);
    }


    public void createHelix(final Block player, final EnumParticle pa, final int number, final double radius) {
        new BukkitRunnable() {
            @Override
            public void run() {
                Location loc = player.getLocation();
                PacketPlayOutWorldParticles packet = new PacketPlayOutWorldParticles(pa, true, (float) (loc.getX()), (float) (loc.getY()), (float) (loc.getZ()), 0, 0, 0, 0, 1);
                for (Player online : Bukkit.getOnlinePlayers()) {
                    ((CraftPlayer) online).getHandle().playerConnection.sendPacket(packet);
                }
                this.cancel();
                return;
            }
        }.runTaskAsynchronously(Main.base);
    }
    public void createPlayerHelix(final Player player, final EnumParticle pa, final int number, final double radius) {
        new BukkitRunnable() {
            @Override
            public void run() {
                Location loc = player.getLocation();
                for (double y = 0; y <= number; y += 0.1) {
                    double x = radius * Math.cos(y);
                    double z = radius * Math.sin(y);
                    PacketPlayOutWorldParticles packet = new PacketPlayOutWorldParticles(pa, true, (float) (loc.getX() + x), (float) (loc.getY()), (float) (loc.getZ() + z), 0, 0, 0, 0, 1);
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        ((CraftPlayer) online).getHandle().playerConnection.sendPacket(packet);
                    }
                }
                this.cancel();
                return;
            }
        }.runTaskAsynchronously(Main.base);
    }
}
