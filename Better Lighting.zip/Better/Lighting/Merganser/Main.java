package Better.Lighting.Merganser;

import org.bukkit.plugin.java.JavaPlugin;
import Better.Lighting.Merganser.Commands.RayCommand;

public class Main extends JavaPlugin{
    public static Main base;
    @Override
    public void onEnable() {
        base = this;

        getCommand("shock").setExecutor(new RayCommand());
        getCommand("shocka").setExecutor(new RayCommand());
    }
    public void onDisable(){
        base = null;
    }
}
